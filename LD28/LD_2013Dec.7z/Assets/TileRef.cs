﻿using UnityEngine;
using System.Collections;

public class TileRef : MonoBehaviour
{
	public int x;
	public int y;
}
