﻿using UnityEngine;
using System.Collections;

public class DigBlockRender : MonoBehaviour
{
  public DiggableSurface m_digSurf;

  // Use this for initialization
  void Start()
  {
	
  }
	
  // Update is called once per frame
  void Update()
  {
    if (Input.GetMouseButton(0))
    {
      Ray mr = Camera.main.ScreenPointToRay(Input.mousePosition);
      RaycastHit hitInfo;
      bool isHit = collider.Raycast(mr, out hitInfo, 10000.0f);
      //renderer.material.mainTextureScale

      if (isHit)
      {
        Vector3 localPoint = transform.InverseTransformPoint(hitInfo.point);
        localPoint = new Vector3((localPoint.x / 64.0f + 0.5f) / renderer.material.mainTextureScale.x, 
                                 1.0f, 
                                 (localPoint.z / 64.0f + 0.5f) / renderer.material.mainTextureScale.y);
      }
    }
  }
}
